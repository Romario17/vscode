﻿# digite 'make all' na linha de comando para compilar o código
# Arquivo executável é gerado dentro da pasta debug